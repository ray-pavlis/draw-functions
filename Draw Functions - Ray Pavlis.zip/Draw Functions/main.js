// Draw Functions

let cnv = document.getElementById("my-canvas");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

// Draw platforms
fill("tan");
rect(150, 200, 300, 50, "fill"); // platform base 1
rect(500, 400, 100, 40, "fill"); // platform base 2

fill("green");
rect(150, 200, 300, 10, "fill"); // platform top 1
rect(500, 400, 100, 9, "fill"); // platform top 2

// Draw a robot
fill("gray");
circle(400, 185, 15, "fill");
fill("purple");
rect(375, 140, 50, 50, "fill");
stroke("purple");
lineWidth(3);
line(400, 130, 400, 145);
circle(400, 115, 20, "fill");
line(400, 96, 380, 80);
line(400, 96, 420, 80);
stroke("gray");
line(375, 150, 425, 150);
circle(410, 115, 5, "stroke");