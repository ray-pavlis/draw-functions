// Draw Functions

let cnv = document.getElementById("my-canvas");
let ctx = cnv.getContext("2d");
cnv.width = 800;
cnv.height = 600;

// Draw platforms
drawPlatform(150, 200, 300, 50);
drawPlatform(500, 400, 100, 40);
drawPlatform(200, 300, 70, 30);

// Draw a robot
drawRobot(550, 315);
drawRobot(400, 115);