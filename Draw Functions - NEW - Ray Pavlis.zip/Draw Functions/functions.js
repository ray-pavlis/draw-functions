function stroke(color) {
    ctx.strokeStyle = color;
}

function fill(color) {
    ctx.fillStyle = color;
}

function lineWidth(width) {
    ctx.lineWidth = width;
}

function font(fontSetting) {
    ctx.font = fontSetting;
}

// Draw a Rectangle
function rect(x, y, w, h, mode) {
    if (mode === "fill") {
        ctx.fillRect(x, y, w, h);
    } else if (mode === "stroke") {
        ctx.strokeRect(x, y, w, h);
    }
}

// Draw a Circle
function circle(x, y, r, mode) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    if (mode === "fill") {
        ctx.fill();
    } else if (mode === "stroke") {
        ctx.stroke();
    }
}

// Draw a Line
function line(x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.moveTo(x1, y1); // Endpoint 1
    ctx.lineTo(x2, y2); // Endpoint 2
    ctx.stroke();
}

// Draw a Platform
function drawPlatform(x, y, w, h) {
    fill("tan");
    rect(x, y, w, h, "fill");
    fill("green");
    rect(x, y, w, 10, "fill");
}

function drawRobot(x, y) {
    fill("gray");
    circle(x + 0, y + 70, 15, "fill"); // Wheel
    fill("purple");
    rect(x - 20, y + 25, 40, 50, "fill"); // Body
    stroke("purple");
    lineWidth(3);
    line(x + 0, y + 0, x + 0, y + 50); // Neck
    circle(x, y, 20, "fill"); // Head
    line(x + 0, y - 20, x - 15, y - 40); // Left Antenna
    line(x + 0, y - 20, x + 15, y - 40); // Right Antenna
    stroke("gray");
    line(x - 20, y + 30, x + 20, y + 30); // Torso line
    circle(x + 10, y + 0, 5, "stroke"); // Eye
}